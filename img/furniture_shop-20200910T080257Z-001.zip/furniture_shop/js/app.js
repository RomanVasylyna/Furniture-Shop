$(document).ready(() => {

/*
let imgs = document.querySelectorAll('.img-fluid');
let circles = document.querySelectorAll('.displayNone');

for(let i = 0; i < imgs.length; i++) {
imgs[i].addEventListener('mouseover', function() {
circles[i].classList.remove('d-none');
})
}

for(let j = 0; j < imgs.length; j++) {
document.querySelectorAll('.col-lg-4')[j].addEventListener('mouseout', function() {
circles[j].classList.add('d-none');
})
}
*/

$('.displayNone').on('mouseover', () => {
$(this).removeClass('d-none');
})
















})
